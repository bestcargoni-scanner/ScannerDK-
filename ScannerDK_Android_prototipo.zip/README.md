# ScannerDK Android (prototipo)

Proyecto Android nativo inicial para escáner Deriv R_25 en M5/M15, modo lectura.

## Importante
- Esto es **código fuente de prototipo**, no APK listo ni verificado.
- El servicio foreground mantiene una notificación mientras está activo; Android/ fabricante puede detenerlo por batería, permisos o políticas.
- El código actual incluye una lógica de señales de ejemplo EMA9/EMA21 + RSI. **No replica todas las reglas del HTML mejorado** (EMA50, ATR, filtros de momentum/vela, TP/SL) y debe revisarse/probarse antes de usar para decisiones.
- No manda órdenes a Deriv. No usa token.
- Para compilar se requiere Android Studio/Gradle con SDK Android. Este ZIP no contiene APK.
- No usar señales para operar con dinero real; probar en demo y verificar manualmente.
