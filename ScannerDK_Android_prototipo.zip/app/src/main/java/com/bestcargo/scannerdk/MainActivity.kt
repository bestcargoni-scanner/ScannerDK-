package com.bestcargo.scannerdk

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 60, 36, 36)
        }
        layout.addView(TextView(this).apply {
            text = "ScannerDK · Volatility 25 (R_25)\nM5 + M15 · Solo lectura"
            textSize = 22f
        })
        layout.addView(TextView(this).apply {
            text = "\nEl servicio muestra una notificación permanente mientras está activo. No ejecuta operaciones."
            textSize = 16f
        })
        layout.addView(Button(this).apply {
            text = "INICIAR ESCÁNER"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
                } else startScanner()
            }
        })
        layout.addView(Button(this).apply {
            text = "DETENER ESCÁNER"
            setOnClickListener { stopService(Intent(this@MainActivity, ScannerService::class.java)); Toast.makeText(this@MainActivity, "Scanner detenido", Toast.LENGTH_SHORT).show() }
        })
        setContentView(layout)
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startScanner()
        else Toast.makeText(this, "Permite notificaciones para recibir avisos.", Toast.LENGTH_LONG).show()
    }
    private fun startScanner() {
        val intent = Intent(this, ScannerService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        Toast.makeText(this, "ScannerDK iniciado", Toast.LENGTH_SHORT).show()
    }
}
