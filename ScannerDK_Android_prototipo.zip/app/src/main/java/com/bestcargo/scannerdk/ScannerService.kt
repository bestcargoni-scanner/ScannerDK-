package com.bestcargo.scannerdk

import android.app.*
import android.content.Intent
import android.os.*
import androidx.core.app.NotificationCompat
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.math.abs

/**
 * Prototipo de servicio foreground. Usa WebSocket público de Deriv y únicamente
 * solicita velas/ticks; nunca envía buy/sell ni requiere token.
 */
class ScannerService : Service() {
    private val channelId = "scannerdk_running"
    private val notificationId = 2501
    private var socket: WebSocket? = null
    private val client = OkHttpClient.Builder().pingInterval(25, TimeUnit.SECONDS).build()
    private val candles5 = mutableListOf<Candle>()
    private val candles15 = mutableListOf<Candle>()
    private var lastM5Epoch = 0L
    private var lastAlertKey = ""
    private var reconnectHandler: Handler? = null
    private var reconnectRunnable: Runnable? = null

    data class Candle(val epoch: Long, val open: Double, val high: Double, val low: Double, val close: Double)

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(notificationId, notification("Conectando a Deriv · R_25"))
        connect()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "ScannerDK activo", NotificationManager.IMPORTANCE_LOW)
            channel.description = "Notificación permanente mientras ScannerDK escanea"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(text: String): Notification {
        val pending = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_popup_sync)
            .setContentTitle("ScannerDK · V25")
            .setContentText(text)
            .setContentIntent(pending)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(notificationId, notification(text))
    }

    private fun connect() {
        socket?.cancel()
        val req = Request.Builder().url("wss://ws.derivws.com/websockets/v3?app_id=1089").build()
        socket = client.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                updateNotification("Conectado · V25 · M5/M15 · Solo lectura")
                webSocket.send(JSONObject().put("ticks", "R_25").put("subscribe", 1).toString())
                requestCandles(webSocket, 300, 300) // M5
                requestCandles(webSocket, 900, 200) // M15
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val root = JSONObject(text)
                    if (root.has("candles")) {
                        val reqId = root.optInt("req_id")
                        val arr = root.getJSONArray("candles")
                        val list = if (reqId == 5) candles5 else candles15
                        list.clear()
                        for (i in 0 until arr.length()) {
                            val c = arr.getJSONObject(i)
                            list.add(Candle(c.getLong("epoch"), c.getDouble("open"), c.getDouble("high"), c.getDouble("low"), c.getDouble("close")))
                        }
                        if (reqId == 5) analyze()
                    } else if (root.has("tick")) {
                        val tick = root.getJSONObject("tick")
                        val quote = tick.optDouble("quote")
                        updateNotification("V25 ${"%.2f".format(quote)} · Escaneando M5/M15")
                    } else if (root.has("error")) {
                        updateNotification("Deriv: ${root.getJSONObject("error").optString("message")}")
                    }
                } catch (_: Exception) { }
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                updateNotification("Conexión perdida · reconectando…")
                scheduleReconnect()
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { scheduleReconnect() }
        })
    }

    private fun requestCandles(ws: WebSocket, granularity: Int, count: Int) {
        val reqId = if (granularity == 300) 5 else 15
        val obj = JSONObject().put("ticks_history", "R_25")
            .put("adjust_start_time", 1).put("count", count)
            .put("end", "latest").put("granularity", granularity)
            .put("style", "candles").put("req_id", reqId)
        ws.send(obj.toString())
    }

    private fun analyze() {
        if (candles5.size < 60 || candles15.size < 60) return
        val c5 = candles5.dropLast(1) // excluir vela en formación
        val c15 = candles15.dropLast(1)
        if (c5.isEmpty() || c5.last().epoch == lastM5Epoch) return
        lastM5Epoch = c5.last().epoch
        val e5 = ema(c5.map { it.close }, 9) to ema(c5.map { it.close }, 21)
        val e15 = ema(c15.map { it.close }, 9) to ema(c15.map { it.close }, 21)
        val r5 = rsi(c5.map { it.close }, 14)
        val r15 = rsi(c15.map { it.close }, 14)
        val bullish = e5.first > e5.second && e15.first > e15.second && c5.last().close > e5.first && r5 in 50.0..68.0 && r15 in 50.0..70.0
        val bearish = e5.first < e5.second && e15.first < e15.second && c5.last().close < e5.first && r5 in 32.0..50.0 && r15 in 30.0..50.0
        val dir = when { bullish -> "BUY"; bearish -> "SELL"; else -> null } ?: return
        val key = "$dir-${c5.last().epoch}"
        if (key == lastAlertKey) return
        lastAlertKey = key
        val msg = "Señal $dir confirmada · M5/M15 · ${"%.2f".format(c5.last().close)}"
        updateNotification(msg)
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify((c5.last().epoch % 100000).toInt(), NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("ScannerDK · $dir")
            .setContentText(msg).setAutoCancel(true).build())
    }

    private fun ema(values: List<Double>, period: Int): Double {
        val k = 2.0 / (period + 1)
        var result = values.take(period).average()
        for (v in values.drop(period)) result = v * k + result * (1-k)
        return result
    }
    private fun rsi(values: List<Double>, period: Int): Double {
        if (values.size <= period) return 50.0
        var gain = 0.0; var loss = 0.0
        for (i in 1..period) { val d=values[i]-values[i-1]; if(d>0) gain+=d else loss-=d }
        var ag=gain/period; var al=loss/period
        for (i in period+1 until values.size) {
            val d=values[i]-values[i-1]
            ag=(ag*(period-1)+maxOf(d,0.0))/period
            al=(al*(period-1)+maxOf(-d,0.0))/period
        }
        if (al==0.0) return 100.0
        return 100.0 - 100.0/(1.0+ag/al)
    }
    private fun scheduleReconnect() {
        if (reconnectHandler == null) reconnectHandler = Handler(Looper.getMainLooper())
        reconnectRunnable?.let { reconnectHandler?.removeCallbacks(it) }
        reconnectRunnable = Runnable { connect() }
        reconnectHandler?.postDelayed(reconnectRunnable!!, 5000)
    }
    override fun onDestroy() {
        socket?.close(1000, "service stopped")
        reconnectRunnable?.let { reconnectHandler?.removeCallbacks(it) }
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
